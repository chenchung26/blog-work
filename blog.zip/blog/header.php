<?php?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ブログシステム</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="site-header">
  <h1><a href="index.php">ブログシステム</a></h1>
  <nav>
    <a href="create_post.php">＋ 新規投稿</a>
    <a href="tags.php">タグ管理</a>
  </nav>
</header>
<main class="container">
